package quest.jdbc;
import java.sql.*;

public class Database {

    public static void main(String[] args) {
        
        String url = "jdbc:mysql://localhost:3306/wild_db_quest";
        String user = "bernd";
        String password = "rio123";
        

        try (Connection conn = DriverManager.getConnection(url, user, password)) {

            System.out.println("Erfolgreich mit Datenbank verbunden.");



            // Einfügen 
            String query = "INSERT INTO persons (firstname, lastname, age) VALUES ('Max', 'Mustermann', '49')";
            Statement stmt = conn.createStatement();
            stmt.execute(query);

            // Update // statt lastname habe ich firstname genommen
            String query2 = "UPDATE persons SET firstname ='Paul' WHERE firstname = 'Pauline'";
            Statement stmt2 = conn.createStatement();
            stmt.execute(query2);
           // stmt.close();

            String query3 = "INSERT INTO persons (firstname, lastname, age) VALUES ('Pauline', 'Musterfrau', '39')";
            Statement stmt3= conn.createStatement();
            stmt.execute(query3);
           // stmt2.close();

           // Delete ------------------------------------------
            
            
           Statement stmt4 = conn.createStatement();
           String delete = "DELETE FROM persons WHERE firstname = 'Paul'";
           int rowsaffected = stmt4.executeUpdate(delete);
           System.out.println ("Rows affected delete: " + rowsaffected);
            //stmt3.close();
        
            // Ausgeben
            query = "SELECT * FROM persons";
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);


            
            int columns = rs.getMetaData().getColumnCount();
            for (int i = 1; i <=columns; i++)
                System.out.print(String.format("%-15s", rs.getMetaData().getColumnLabel(i))); //Überschriften linksbündig 15 Zeichen sichtbar
            System.out.println();
            System.out.println("--------------------------------------------------"); // Trenner

            while(rs.next()) {
                for (int i = 1; i <=columns; i++) 
                System.out.print(String.format("%-15s", rs.getString(i)));
            System.out.println();
            }
        
            rs.close();
            stmt.close();
            stmt2.close();
            stmt3.close();
            // stmt4.close();

        }catch(SQLException ex){

            System.err.println(ex.getMessage());
        }

    }



}